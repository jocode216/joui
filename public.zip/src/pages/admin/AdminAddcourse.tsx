import React from 'react'

function AdminAddcourse() {
  return (
    <div>
      
    </div>
  )
}

export default AdminAddcourse
