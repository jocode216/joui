import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import DashboardLayout from "@/components/layout/DashboardLayout";
import { useRole } from "@/contexts/RoleContext";
import StatCard from "@/components/StatCard";
import CourseCard from "@/components/CourseCard";
import {
  BookOpen,
  Users,
  GraduationCap,
  ClipboardList,
  DollarSign,
  Clock,
  CheckCircle,
} from "lucide-react";

// API base URL - use import.meta.env for Vite or fallback to localhost
const API_BASE = import.meta.env?.VITE_API_URL || "http://localhost:3000/api";

// Loading component
const LoadingSpinner = () => (
  <div className="flex items-center justify-center min-h-[400px]">
    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
  </div>
);

// Error component
const ErrorMessage = ({ message, onRetry }) => (
  <div className="dash-card p-8 text-center">
    <p className="text-destructive mb-4">{message}</p>
    {onRetry && (
      <button onClick={onRetry} className="btn-primary">
        Try Again
      </button>
    )}
  </div>
);

// Helper function for API calls
const apiCall = async (endpoint, options = {}) => {
  const token = localStorage.getItem("token");
  const response = await fetch(`${API_BASE}${endpoint}`, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...(token && { Authorization: `Bearer ${token}` }),
      ...options.headers,
    },
  });

  let data;
  try {
    data = await response.json();
  } catch (e) {
    data = { error: "Invalid response from server" };
  }

  if (!response.ok) {
    throw new Error(
      data.error || `Request failed with status ${response.status}`,
    );
  }

  return data;
};

// ==================== USER DASHBOARD ====================
function UserDashboard() {
  const [enrollments, setEnrollments] = useState([]);
  const [pendingRequests, setPendingRequests] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchUserData = async () => {
    try {
      setLoading(true);

      // Check if token exists
      const token = localStorage.getItem("token");
      if (!token) {
        throw new Error("No authentication token found");
      }

      // Fetch user's enrollments
      const data = await apiCall("/my-enrollments");

      // Handle different response structures
      const enrollmentsData =
        data.data?.active_enrollments || data.enrollments || [];
      const requestsData =
        data.data?.pending_requests || data.pending_requests || [];

      setEnrollments(enrollmentsData);
      setPendingRequests(requestsData);
    } catch (err) {
      console.error("Error fetching user data:", err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUserData();
  }, []);

  if (loading) return <LoadingSpinner />;
  if (error) return <ErrorMessage message={error} onRetry={fetchUserData} />;

  const hasEnrolledCourses = enrollments.length > 0;

  return (
    <div>
      <h1 className="page-header">My Dashboard</h1>

      {/* Status Card - Removed bgColor */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <StatCard
          title="Enrolled Courses"
          value={enrollments.length}
          icon={BookOpen}
        />
        <StatCard
          title="Pending Requests"
          value={pendingRequests.length}
          icon={Clock}
        />
        <StatCard
          title="In Progress"
          value={
            enrollments.filter((e) => e.progress > 0 && e.progress < 100).length
          }
          icon={BookOpen}
        />
      </div>

      {/* Pending Requests Section */}
      {pendingRequests.length > 0 && (
        <div className="mb-6">
          <h2 className="text-lg font-semibold text-foreground mb-4">
            Pending Enrollment Requests
          </h2>
          <div className="space-y-3">
            {pendingRequests.map((request) => (
              <div
                key={request.request_id || request.id || Math.random()}
                className="dash-card p-4 flex items-center justify-between"
              >
                <div>
                  <h3 className="font-semibold text-foreground">
                    {request.course_title ||
                      request.package_title ||
                      request.title ||
                      "Course"}
                  </h3>
                  <p className="text-xs text-muted-foreground mt-1">
                    Requested on:{" "}
                    {request.created_at
                      ? new Date(request.created_at).toLocaleDateString()
                      : "N/A"}
                  </p>
                  {request.notes && (
                    <p className="text-xs text-muted-foreground mt-1">
                      Note: {request.notes}
                    </p>
                  )}
                </div>
                <span className="px-3 py-1 bg-yellow-100 dark:bg-yellow-900/30 text-yellow-700 dark:text-yellow-400 rounded-full text-xs font-medium">
                  Pending Approval
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Enrolled Courses Section */}
      <h2 className="text-lg font-semibold text-foreground mb-4">My Courses</h2>

      {!hasEnrolledCourses ? (
        <div className="dash-card p-8 text-center">
          <BookOpen className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
          <p className="text-muted-foreground mb-4">
            You are not enrolled in any course yet.
          </p>
          <Link to="/courses" className="btn-primary inline-block no-underline">
            Browse Courses
          </Link>
        </div>
      ) : (
        <div className="grid md:grid-cols-2 gap-5">
          {enrollments.map((enrollment) => (
            <CourseCard
              key={enrollment.enrollment_id || enrollment.id || Math.random()}
              id={enrollment.course_id || enrollment.id}
              title={enrollment.title || "Untitled Course"}
              description={enrollment.description || ""}
              imageUrl={enrollment.image_url}
              teacherName={
                enrollment.teacher_first_name && enrollment.teacher_last_name
                  ? `${enrollment.teacher_first_name} ${enrollment.teacher_last_name}`
                  : enrollment.teacher_name || "Instructor"
              }
              progress={enrollment.progress || 0}
              showGoToCourse
            />
          ))}
        </div>
      )}
    </div>
  );
}

// ==================== TEACHER DASHBOARD ====================
function TeacherDashboard() {
  const [courses, setCourses] = useState([]);
  const [stats, setStats] = useState({
    courses: {
      total: 0,
      active: 0,
      pending: 0,
      rejected: 0,
    },
    lessons: {
      total: 0,
      avg_duration: 0,
    },
    students: {
      total: 0,
      total_enrollments: 0,
    },
    recent_enrollments: [],
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchTeacherData = async () => {
    try {
      setLoading(true);

      // Check if token exists
      const token = localStorage.getItem("token");
      if (!token) {
        throw new Error("No authentication token found");
      }

      // Fetch teacher's courses
      const coursesData = await apiCall("/teacher/courses");
      setCourses(coursesData.data || coursesData || []);

      // Fetch teacher stats
      try {
        const statsData = await apiCall("/teacher/stats");
        setStats(statsData.data || statsData);
      } catch (statsErr) {
        console.warn("Could not fetch teacher stats:", statsErr);
        // Don't fail completely if stats endpoint fails
      }
    } catch (err) {
      console.error("Error fetching teacher data:", err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTeacherData();
  }, []);

  if (loading) return <LoadingSpinner />;
  if (error) return <ErrorMessage message={error} onRetry={fetchTeacherData} />;

  const totalStudents = stats.students?.total || 0;
  const totalRevenue = courses.reduce(
    (sum, course) => sum + (Number(course.price) || 0),
    0,
  );

  return (
    <div>
      <h1 className="page-header">Teacher Dashboard</h1>

      {/* Stats Grid - Removed bgColor */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <StatCard title="Total Students" value={totalStudents} icon={Users} />
        <StatCard
          title="Total Revenue"
          value={`$${totalRevenue.toLocaleString()}`}
          icon={DollarSign}
        />
        <StatCard
          title="Active Courses"
          value={
            stats.courses?.active ||
            courses.filter((c) => c.status === "APPROVED").length
          }
          icon={BookOpen}
        />
        <StatCard
          title="Pending Review"
          value={
            stats.courses?.pending ||
            courses.filter((c) => c.status === "PENDING").length
          }
          icon={Clock}
        />
      </div>

      {/* My Courses Section */}
      <h2 className="text-lg font-semibold text-foreground mb-4">My Courses</h2>

      {courses.length === 0 ? (
        <div className="dash-card p-8 text-center">
          <BookOpen className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
          <p className="text-muted-foreground mb-4">
            You haven't created any courses yet.
          </p>
          <Link
            to="/courses/create"
            className="btn-primary inline-block no-underline"
          >
            Create Your First Course
          </Link>
        </div>
      ) : (
        <div className="space-y-3">
          {courses.map((course) => (
            <div
              key={course.id}
              className="dash-card p-4 flex items-center justify-between"
            >
              <div className="flex-1">
                <div className="flex items-center gap-3">
                  <h3 className="font-semibold text-foreground">
                    {course.title}
                  </h3>
                  {course.status === "PENDING" && (
                    <span className="px-2 py-1 bg-yellow-100 dark:bg-yellow-900/30 text-yellow-700 dark:text-yellow-400 rounded-full text-xs font-medium">
                      Pending
                    </span>
                  )}
                  {course.status === "APPROVED" && (
                    <span className="px-2 py-1 bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400 rounded-full text-xs font-medium">
                      Approved
                    </span>
                  )}
                  {course.status === "REJECTED" && (
                    <span className="px-2 py-1 bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-400 rounded-full text-xs font-medium">
                      Rejected
                    </span>
                  )}
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  {course.lessons_count || 0} lessons ·{" "}
                  {course.enrollments_count || 0} students enrolled
                </p>
              </div>
              <div className="flex items-center gap-3">
                {course.status === "APPROVED" && (
                  <Link
                    to={`/courses/${course.id}/students`}
                    className="btn-outline-primary text-xs px-3 py-1.5 no-underline"
                  >
                    View Students
                  </Link>
                )}
                <Link
                  to={`/courses/${course.id}/edit`}
                  className="btn-outline-secondary text-xs px-3 py-1.5 no-underline"
                >
                  Edit
                </Link>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Recent Enrollments */}
      {stats.recent_enrollments && stats.recent_enrollments.length > 0 && (
        <div className="mt-8">
          <h2 className="text-lg font-semibold text-foreground mb-4">
            Recent Enrollments
          </h2>
          <div className="dash-card overflow-hidden">
            <table className="w-full">
              <thead className="bg-muted/50">
                <tr>
                  <th className="text-left text-xs font-medium text-muted-foreground p-3">
                    Student
                  </th>
                  <th className="text-left text-xs font-medium text-muted-foreground p-3">
                    Course
                  </th>
                  <th className="text-left text-xs font-medium text-muted-foreground p-3">
                    Date
                  </th>
                </tr>
              </thead>
              <tbody>
                {stats.recent_enrollments.map((enrollment, index) => (
                  <tr key={index} className="border-t border-border">
                    <td className="p-3 text-sm">
                      {enrollment.first_name} {enrollment.last_name}
                    </td>
                    <td className="p-3 text-sm">{enrollment.course_title}</td>
                    <td className="p-3 text-sm text-muted-foreground">
                      {enrollment.created_at || enrollment.enrolled_at
                        ? new Date(
                            enrollment.created_at || enrollment.enrolled_at,
                          ).toLocaleDateString()
                        : "N/A"}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}

// ==================== ADMIN DASHBOARD ====================
function AdminDashboard() {
  const [stats, setStats] = useState({
    summary: {
      total_users: 0,
      students: 0,
      teachers: 0,
      admins: 0,
      active_users: 0,
      new_today: 0,
      new_this_week: 0,
      new_this_month: 0,
    },
    teacher_requests: {
      total_requests: 0,
      pending_requests: 0,
      approved_teachers: 0,
      rejected_requests: 0,
    },
    top_enrolled_students: [],
    top_teachers: [],
    recent_users: [],
  });
  const [courseStats, setCourseStats] = useState({
    summary: {
      total_courses: 0,
      pending_courses: 0,
      approved_courses: 0,
      rejected_courses: 0,
    },
    top_courses: [],
    recent_courses: [],
    category_breakdown: [],
  });
  const [enrollmentStats, setEnrollmentStats] = useState({
    enrollments: {
      total_enrollments: 0,
      total_students: 0,
    },
    requests: {
      total_requests: 0,
      pending_requests: 0,
      approved_requests: 0,
      rejected_requests: 0,
    },
    popular_courses: [],
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchAdminData = async () => {
    try {
      setLoading(true);

      // Check if token exists
      const token = localStorage.getItem("token");
      if (!token) {
        throw new Error("No authentication token found");
      }

      // Fetch all stats in parallel for better performance
      const [userStatsData, courseStatsData, enrollmentStatsData] =
        await Promise.allSettled([
          apiCall("/admin/users/stats"),
          apiCall("/admin/courses/stats"),
          apiCall("/admin/enrollments/stats"),
        ]);

      if (userStatsData.status === "fulfilled") {
        setStats(userStatsData.value.data || userStatsData.value);
      }

      if (courseStatsData.status === "fulfilled") {
        setCourseStats(courseStatsData.value.data || courseStatsData.value);
      }

      if (enrollmentStatsData.status === "fulfilled") {
        setEnrollmentStats(
          enrollmentStatsData.value.data || enrollmentStatsData.value,
        );
      }
    } catch (err) {
      console.error("Error fetching admin data:", err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAdminData();
  }, []);

  if (loading) return <LoadingSpinner />;
  if (error) return <ErrorMessage message={error} onRetry={fetchAdminData} />;

  const pendingTotal =
    (stats.teacher_requests?.pending_requests || 0) +
    (enrollmentStats.requests?.pending_requests || 0);

  return (
    <div>
      <h1 className="page-header">Admin Dashboard</h1>

      {/* Main Stats Grid - Removed bgColor */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatCard
          title="Total Users"
          value={stats.summary?.total_users || 0}
          icon={Users}
        />
        <StatCard
          title="Total Teachers"
          value={stats.summary?.teachers || 0}
          icon={GraduationCap}
        />
        <StatCard
          title="Total Courses"
          value={courseStats.summary?.total_courses || 0}
          icon={BookOpen}
        />
        <StatCard
          title="Pending Requests"
          value={pendingTotal}
          icon={ClipboardList}
        />
      </div>

      {/* Second Stats Row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <StatCard
          title="Active Users"
          value={stats.summary?.active_users || 0}
          icon={CheckCircle}
        />
        <StatCard
          title="New Today"
          value={stats.summary?.new_today || 0}
          icon={Clock}
        />
        <StatCard
          title="Pending Courses"
          value={courseStats.summary?.pending_courses || 0}
          icon={Clock}
        />
        <StatCard
          title="Total Enrollments"
          value={enrollmentStats.enrollments?.total_enrollments || 0}
          icon={Users}
        />
      </div>

      {/* Top Students and Teachers */}
      <div className="grid lg:grid-cols-2 gap-6 mb-8">
        {/* Top Enrolled Students */}
        <div className="dash-card p-6">
          <h2 className="text-lg font-semibold text-foreground mb-4">
            Top Enrolled Students
          </h2>
          {!stats.top_enrolled_students ||
          stats.top_enrolled_students.length === 0 ? (
            <p className="text-muted-foreground text-sm">No data available</p>
          ) : (
            <div className="space-y-3">
              {stats.top_enrolled_students.map((student, index) => (
                <div
                  key={student.id || index}
                  className="flex items-center justify-between"
                >
                  <div className="flex items-center gap-3">
                    <span className="text-sm font-medium text-muted-foreground w-6">
                      #{index + 1}
                    </span>
                    <div>
                      <p className="text-sm font-medium text-foreground">
                        {student.first_name} {student.last_name}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {student.email}
                      </p>
                    </div>
                  </div>
                  <span className="text-sm font-semibold text-primary">
                    {student.total_enrollments} enrollments
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Top Teachers */}
        <div className="dash-card p-6">
          <h2 className="text-lg font-semibold text-foreground mb-4">
            Top Teachers
          </h2>
          {!stats.top_teachers || stats.top_teachers.length === 0 ? (
            <p className="text-muted-foreground text-sm">No data available</p>
          ) : (
            <div className="space-y-3">
              {stats.top_teachers.map((teacher, index) => (
                <div
                  key={teacher.id || index}
                  className="flex items-center justify-between"
                >
                  <div className="flex items-center gap-3">
                    <span className="text-sm font-medium text-muted-foreground w-6">
                      #{index + 1}
                    </span>
                    <div>
                      <p className="text-sm font-medium text-foreground">
                        {teacher.first_name} {teacher.last_name}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {teacher.email}
                      </p>
                    </div>
                  </div>
                  <span className="text-sm font-semibold text-primary">
                    {teacher.approved_courses || teacher.approved_packages || 0}{" "}
                    courses
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Recent Users */}
      <div className="mb-8">
        <h2 className="text-lg font-semibold text-foreground mb-4">
          Recent Users
        </h2>
        <div className="dash-card overflow-hidden">
          <table className="w-full">
            <thead className="bg-muted/50">
              <tr>
                <th className="text-left text-xs font-medium text-muted-foreground p-3">
                  Name
                </th>
                <th className="text-left text-xs font-medium text-muted-foreground p-3">
                  Email
                </th>
                <th className="text-left text-xs font-medium text-muted-foreground p-3">
                  Role
                </th>
                <th className="text-left text-xs font-medium text-muted-foreground p-3">
                  Joined
                </th>
              </tr>
            </thead>
            <tbody>
              {stats.recent_users &&
                stats.recent_users.map((user) => (
                  <tr key={user.id} className="border-t border-border">
                    <td className="p-3 text-sm">
                      {user.first_name} {user.last_name}
                    </td>
                    <td className="p-3 text-sm">{user.email}</td>
                    <td className="p-3 text-sm">
                      <span
                        className={`px-2 py-1 rounded-full text-xs font-medium ${
                          user.role === "ADMIN"
                            ? "bg-purple-100 dark:bg-purple-900/30 text-purple-700 dark:text-purple-400"
                            : user.role === "TEACHER"
                              ? "bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-400"
                              : "bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400"
                        }`}
                      >
                        {user.role}
                      </span>
                    </td>
                    <td className="p-3 text-sm text-muted-foreground">
                      {user.created_at
                        ? new Date(user.created_at).toLocaleDateString()
                        : "N/A"}
                    </td>
                  </tr>
                ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="dash-card p-6">
        <h2 className="text-lg font-semibold text-foreground mb-4">
          Quick Actions
        </h2>
        <div className="flex flex-wrap gap-3">
          <Link
            to="/admin/users"
            className="btn-primary text-sm px-4 py-2 no-underline"
          >
            Manage Users
          </Link>
          <Link
            to="/admin/courses"
            className="btn-primary text-sm px-4 py-2 no-underline"
          >
            Manage Courses
          </Link>
          <Link
            to="/admin/teacher-requests"
            className="btn-outline-primary text-sm px-4 py-2 no-underline"
          >
            Teacher Requests ({stats.teacher_requests?.pending_requests || 0})
          </Link>
          <Link
            to="/admin/enrollment-requests"
            className="btn-outline-primary text-sm px-4 py-2 no-underline"
          >
            Enrollment Requests (
            {enrollmentStats.requests?.pending_requests || 0})
          </Link>
        </div>
      </div>
    </div>
  );
}

// Main Dashboard component with proper type handling
export default function Dashboard() {
  const { role } = useRole();

  // Convert role to string for comparison
  const userRole = String(role).toUpperCase();

  return (
    <DashboardLayout>
      {userRole === "STUDENT" && <UserDashboard />}
      {userRole === "TEACHER" && <TeacherDashboard />}
      {userRole === "ADMIN" && <AdminDashboard />}

      {/* Fallback for unknown roles */}
      {!["STUDENT", "TEACHER", "ADMIN"].includes(userRole) && (
        <div className="dash-card p-8 text-center">
          <p className="text-muted-foreground">
            Unknown user role. Please contact support.
          </p>
        </div>
      )}
    </DashboardLayout>
  );
}
