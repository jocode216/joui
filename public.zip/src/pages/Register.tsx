import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import PublicHeader from "@/components/layout/PublicHeader";
import Footer from "@/dataIhave/footer/Footer";

interface FormData {
  first_name: string;
  last_name: string;
  email: string;
  phone: string;
  password: string;
  confirm_password: string;
}

interface ValidationErrors {
  first_name?: string;
  last_name?: string;
  email?: string;
  phone?: string;
  password?: string;
  confirm_password?: string;
}

export default function Register() {
  const [formData, setFormData] = useState<FormData>({
    first_name: "",
    last_name: "",
    email: "",
    phone: "",
    password: "",
    confirm_password: "",
  });
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string>("");
  const [validationErrors, setValidationErrors] = useState<ValidationErrors>(
    {},
  );

  const navigate = useNavigate();

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
    // Clear error for this field when user starts typing
    if (validationErrors[name as keyof ValidationErrors]) {
      setValidationErrors((prev) => ({
        ...prev,
        [name]: "",
      }));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    setValidationErrors({});

    try {
      const response = await fetch("http://localhost:3000/api/register", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      });

      const data = await response.json();

      if (!response.ok) {
        // Handle validation errors
        if (data.error === "Validation failed" && data.details) {
          const errors: ValidationErrors = {};
          data.details.forEach((err: { field: string; message: string }) => {
            errors[err.field as keyof ValidationErrors] = err.message;
          });
          setValidationErrors(errors);
          throw new Error("Please check your input");
        }
        throw new Error(data.error || "Registration failed");
      }

      // Success - store token and redirect
      if (data.data.token) {
        localStorage.setItem("token", data.data.token);
        localStorage.setItem(
          "user",
          JSON.stringify({
            userId: data.data.userId,
            firstName: data.data.firstName,
            lastName: data.data.lastName,
            email: data.data.email,
            role: data.data.role,
          }),
        );
      }

      // Redirect to dashboard
      navigate("/dashboard");
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : "An error occurred during registration",
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <PublicHeader />
      <div className="flex items-center justify-center px-4 py-20">
        <div className="w-full max-w-md">
          <div className="dash-card p-8">
            <h1 className="text-2xl font-bold text-foreground mb-1">
              Create an account
            </h1>
            <p className="text-sm text-muted-foreground mb-6">
              Join Jocode and start learning today
            </p>

            {error && (
              <div className="mb-4 p-3 bg-destructive/10 border border-destructive/20 rounded-lg">
                <p className="text-sm text-destructive">{error}</p>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-foreground mb-1.5">
                    First Name <span className="text-destructive">*</span>
                  </label>
                  <input
                    type="text"
                    name="first_name"
                    value={formData.first_name}
                    onChange={handleChange}
                    className={`w-full px-3 py-2.5 rounded-lg border ${
                      validationErrors.first_name
                        ? "border-destructive"
                        : "border-input"
                    } bg-background text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-primary/20`}
                    placeholder="John"
                    required
                  />
                  {validationErrors.first_name && (
                    <p className="mt-1 text-xs text-destructive">
                      {validationErrors.first_name}
                    </p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground mb-1.5">
                    Last Name <span className="text-destructive">*</span>
                  </label>
                  <input
                    type="text"
                    name="last_name"
                    value={formData.last_name}
                    onChange={handleChange}
                    className={`w-full px-3 py-2.5 rounded-lg border ${
                      validationErrors.last_name
                        ? "border-destructive"
                        : "border-input"
                    } bg-background text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-primary/20`}
                    placeholder="Doe"
                    required
                  />
                  {validationErrors.last_name && (
                    <p className="mt-1 text-xs text-destructive">
                      {validationErrors.last_name}
                    </p>
                  )}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-foreground mb-1.5">
                  Email <span className="text-destructive">*</span>
                </label>
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  className={`w-full px-3 py-2.5 rounded-lg border ${
                    validationErrors.email
                      ? "border-destructive"
                      : "border-input"
                  } bg-background text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-primary/20`}
                  placeholder="you@example.com"
                  required
                />
                {validationErrors.email && (
                  <p className="mt-1 text-xs text-destructive">
                    {validationErrors.email}
                  </p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-foreground mb-1.5">
                  Phone (Optional)
                </label>
                <input
                  type="tel"
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                  className="w-full px-3 py-2.5 rounded-lg border border-input bg-background text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-primary/20"
                  placeholder="+1234567890"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-foreground mb-1.5">
                  Password <span className="text-destructive">*</span>
                </label>
                <input
                  type="password"
                  name="password"
                  value={formData.password}
                  onChange={handleChange}
                  className={`w-full px-3 py-2.5 rounded-lg border ${
                    validationErrors.password
                      ? "border-destructive"
                      : "border-input"
                  } bg-background text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-primary/20`}
                  placeholder="••••••••"
                  required
                  minLength={6}
                />
                {validationErrors.password && (
                  <p className="mt-1 text-xs text-destructive">
                    {validationErrors.password}
                  </p>
                )}
                <p className="mt-1 text-xs text-muted-foreground">
                  Must be at least 6 characters
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium text-foreground mb-1.5">
                  Confirm Password
                </label>
                <input
                  type="password"
                  name="confirm_password"
                  value={formData.confirm_password}
                  onChange={handleChange}
                  className={`w-full px-3 py-2.5 rounded-lg border ${
                    validationErrors.confirm_password
                      ? "border-destructive"
                      : "border-input"
                  } bg-background text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-primary/20`}
                  placeholder="••••••••"
                />
                {validationErrors.confirm_password && (
                  <p className="mt-1 text-xs text-destructive">
                    {validationErrors.confirm_password}
                  </p>
                )}
              </div>

              <button
                type="submit"
                className="btn-primary w-full py-3 disabled:opacity-50 disabled:cursor-not-allowed"
                disabled={loading}
              >
                {loading ? (
                  <span className="flex items-center justify-center">
                    <svg
                      className="animate-spin -ml-1 mr-3 h-5 w-5 text-white"
                      xmlns="http://www.w3.org/2000/svg"
                      fill="none"
                      viewBox="0 0 24 24"
                    >
                      <circle
                        className="opacity-25"
                        cx="12"
                        cy="12"
                        r="10"
                        stroke="currentColor"
                        strokeWidth="4"
                      ></circle>
                      <path
                        className="opacity-75"
                        fill="currentColor"
                        d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                      ></path>
                    </svg>
                    Creating account...
                  </span>
                ) : (
                  "Create Account"
                )}
              </button>
            </form>

            <p className="text-sm text-muted-foreground text-center mt-5">
              Already have an account?{" "}
              <Link
                to="/login"
                className="text-primary font-medium hover:underline"
              >
                Sign In
              </Link>
            </p>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}
