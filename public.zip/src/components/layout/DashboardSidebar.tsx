import { Link, useLocation } from "react-router-dom";
import { useRole } from "@/contexts/RoleContext";
import {
  LayoutDashboard,
  BookOpen,
  Users,
  ClipboardList,
  GraduationCap,
  Search,
  ChevronDown,
  ChevronLeft,
  LogOut,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useState } from "react";

const navItems = {
  user: [
    { title: "Dashboard", path: "/dashboard", icon: LayoutDashboard },
    { title: "My Courses", path: "/my-courses", icon: BookOpen },
    { title: "Browse Courses", path: "/courses", icon: Search },
  ],
  teacher: [
    { title: "Dashboard", path: "/dashboard", icon: LayoutDashboard },
    { title: "My Courses", path: "/my-courses", icon: BookOpen },
    { title: "Students", path: "/students", icon: Users },
  ],
  admin: [
    { title: "Dashboard", path: "/dashboard", icon: LayoutDashboard },
    { title: "Users", path: "/admin/users", icon: Users },
    { title: "Courses", path: "/courses", icon: BookOpen },
    { title: "Requests", path: "/admin/requests", icon: ClipboardList },
    { title: "Teachers", path: "/admin/teachers", icon: GraduationCap },
  ],
};

const getInitials = (name: string) =>
  name
    .split(" ")
    .map((p) => p[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();

interface DashboardSidebarProps {
  className?: string;
  onClose?: () => void;
}

export default function DashboardSidebar({ className, onClose }: DashboardSidebarProps) {
  const { role, setRole, userName } = useRole();
  const location = useLocation();
  const items = navItems[role];

  return (
    <aside className={cn(
      "group fixed left-0 top-0 z-40 h-screen w-64 md:w-20 md:hover:w-64 border-r border-border bg-background transition-all duration-300 ease-in-out overflow-hidden shadow-lg",
      className
    )}>
      {/* Header */}
      <div className="flex h-16 items-center border-b border-border px-6 justify-between whitespace-nowrap">
        <Link to="/" className="text-xl font-semibold tracking-tight md:opacity-0 md:group-hover:opacity-100 transition-opacity duration-300">
          Jocode
        </Link>
        {onClose && (
          <button 
            onClick={onClose} 
            className="md:hidden text-muted-foreground hover:text-foreground"
          >
            <ChevronLeft className="h-5 w-5" />
          </button>
        )}
        <span className="ml-2 text-xs text-muted-foreground capitalize hidden md:inline">
          {role}
        </span>
      </div>

      {/* Navigation */}
      <nav className="flex flex-col gap-1 p-4">
        {items.map((item) => {
          const isActive = location.pathname === item.path;
          
          return (
            <Link
              key={item.path}
              to={item.path}
              className={cn(
                'flex items-center gap-3 px-3 py-2 rounded-md transition-colors whitespace-nowrap',
                isActive 
                  ? 'bg-primary text-primary-foreground' 
                  : 'text-muted-foreground hover:bg-muted hover:text-foreground'
              )}
            >
              <item.icon className="h-5 w-5 min-w-[20px]" />
              <span className="md:opacity-0 md:group-hover:opacity-100 transition-opacity duration-300">
                {item.title}
              </span>
            </Link>
          );
        })}
      </nav>

      {/* Footer with Role Switcher and User Info */}
      <div className="absolute bottom-0 left-0 right-0 border-t border-border p-4 whitespace-nowrap">
        {/* Role Switcher */}
        <div className="mb-3">
          <label className="text-xs text-muted-foreground font-medium uppercase tracking-wider block mb-1 md:opacity-0 md:group-hover:opacity-100 transition-opacity duration-300">
            Demo Role
          </label>
          <div className="relative">
            <select
              value={role}
              onChange={(e) => setRole(e.target.value as "user" | "teacher" | "admin")}
              className="w-full appearance-none bg-secondary text-foreground text-sm rounded-lg px-3 py-2 pr-8 border border-border focus:outline-none focus:ring-2 focus:ring-primary/20"
            >
              <option value="user">Student</option>
              <option value="teacher">Teacher</option>
              <option value="admin">Admin</option>
            </select>
            <ChevronDown className="absolute right-2 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
          </div>
        </div>

        {/* User info */}
        <div className="flex items-center gap-3 bg-accent rounded-lg p-2.5">
          <div className="w-9 h-9 rounded-full bg-foreground text-background flex items-center justify-center text-xs font-bold shrink-0">
            {getInitials(userName)}
          </div>
          <div className="min-w-0 md:opacity-0 md:group-hover:opacity-100 transition-opacity duration-300">
            <p className="text-sm font-medium text-foreground truncate">{userName}</p>
            <p className="text-xs text-muted-foreground capitalize">{role}</p>
          </div>
        </div>

        {/* Back to site link */}
        <Link 
          to="/" 
          className="flex items-center gap-3 px-3 py-2 rounded-md text-muted-foreground hover:bg-muted hover:text-foreground transition-colors mt-2"
        >
          <LogOut className="h-5 w-5 min-w-[20px]" />
          <span className="md:opacity-0 md:group-hover:opacity-100 transition-opacity duration-300">
            Back to site
          </span>
        </Link>
      </div>
    </aside>
  );
}